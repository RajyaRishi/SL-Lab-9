export interface TodoItem {
  title: string;
  details: string;
  completed?: boolean;
}
